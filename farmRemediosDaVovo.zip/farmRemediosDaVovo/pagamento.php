<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  
  <meta charset="UTF-8">
  
  <title>Pagamento</title>
  
  <link rel="stylesheet" href="assets/styles/pagamento.css">
  
</head>


<body>
  
  
  <main class="pagamentoPagina">
    
    
    <h1>Forma de pagamento</h1>
    
    
    <label>
      <input type="radio" name="pagamento" value="Cartão de crédito">
      Cartão de crédito
    </label>
    
    
    <br>
    
    
    <label>
      <input type="radio" name="pagamento" value="Pix">
      PIX
    </label>
    
    
    <br>
    
    
    <label>
      <input type="radio" name="pagamento" value="Boleto">
      Boleto
    </label>


    <button onclick="finalizarCompra()">
      Finalizar compra
    </button>
    

<button onclick="cancelarPagamento()">
    Cancelar
</button>
    
    
  </main>
  
  
  <script src="assets/scripts/pagamento.js"></script>

  <script src="assets/scripts/nav.js"></script>

</body>

</html>