<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>Produto</title>
  
  <link rel="stylesheet" href="assets/styles/header.css">
  <link rel="stylesheet" href="assets/styles/produto.css">
  <link rel="stylesheet" href="assets/styles/footer.css">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  
  
</head>

<button id="voltarTopo">
  ↑
</button>

<body>
  
  
  <!-- HEADER + NAV FIXOS -->
  
  <div class="menu-fixo">
    
    
    <header>
      
      <div class="topo">
        
        
        <div class="logo">
          
          <img src="assets/img/logo.jpg" alt="Logo">
          
          <h1>Remédios da vovó</h1>
          
        </div>
        
        
        
        <div class="pesquisa">
          
          <input type="text" placeholder="Pesquisar produtos">
          
          <button>
            <i class="fa-solid fa-magnifying-glass"></i>
          </button>
          
        </div>
        
        
        
        <div class="icones">
          
          <a href="carrinho.php">
            <i class="fa-solid fa-cart-shopping"></i>
          </a>


          <a href="login.php" id="iconeUsuario">
            <i class="fa-solid fa-user"></i>
          </a>

          
        </div>
        
        
      </div>
      
      
    </header>
    
    
    
    <nav>
      
      
      <ul>
        
        
        <li>
          <a href="index.php">Início</a>
        </li>
        
        
        <li>
          <a href="produtos.php">Produtos</a>
        </li>
        
        
        <li>
          <a href="faleConosco.php">Fale Conosco</a>
        </li>
        
        
        <li>
          <a href="index.php#sobre">Sobre nós</a>
        </li>
        
        
        
        
      </ul>



      <div class="login">

        <span>Seja bem vindo(a),</span>

        <a href="login.php" id="linkUsuario">
          Entre ou Cadastre-se
        </a>

      </div>
      
      
    </nav>
    
    
  </div>
    

<main class="produtoDetalhe">


  <div class="imagemGrande">

    <img id="imagemProduto">

  </div>



  <div class="infoProduto">


    <h1 id="nomeProduto"></h1>


    <span id="categoriaProduto"></span>


    <p id="descricaoProduto"></p>



    <h2 id="precoProduto"></h2>



    <button id="adicionarCarrinho">
      Adicionar ao carrinho
    </button>

    <button id="botaoFavorito" type="button">
      <i class="fa-solid fa-heart"></i>
    </button>


  </div>


</main>




<footer>


  <div class="footerContainer">


    <div>

      <h3>Remédios da Vovó</h3>

      <p>
        Qualidade, confiança e cuidado com a sua saúde.
      </p>

    </div>



    <div>

      <h3>Contato</h3>

      <p>(11) 99999-9999</p>

      <p>contato@remediosdavovo.com.br</p>

    </div>



    <div>

      <h3>Horário</h3>

      <p>Segunda a Sexta</p>

      <p>08:00 às 18:00</p>

    </div>


  </div>




  <div class="copyright">

    © 2026 Remédios da Vovó - Todos os direitos reservados.

  </div>


</footer>



  <script src="assets/scripts/nav.js"></script>
<script src="assets/scripts/produto.js"></script>
<script src="assets/scripts/header.js"></script>



</body>

</html>