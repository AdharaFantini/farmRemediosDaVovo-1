<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Meu Perfil - Remédios da Vovó</title>

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="assets/styles/header.css">
    <link rel="stylesheet" href="assets/styles/usuario.css">
    <link rel="stylesheet" href="assets/styles/footer.css">
</head>

<body>

<!-- ================= HEADER ================= -->
<!-- CABEÇALHO -->
<header>

    <div class="topo">

        <div class="logo">

            <img src="assets/img/logo.jpg" alt="Logo">

            <h1>Remédios da vovó</h1>

        </div>

        <div class="pesquisa">

            <input
                    type="text"
                    id="pesquisa"
                    placeholder="Pesquisar produtos">

            <button onclick="pesquisarProduto()">

                <i class="fa-solid fa-magnifying-glass"></i>

            </button>

        </div>

        <div class="icones">

            <a href="carrinho.php">

                <i class="fa-solid fa-cart-shopping"></i>

            </a>

            <a href="login.php" id="iconeUsuario">

                <i class="fa-solid fa-user"></i>

            </a>

        </div>

    </div>

</header>


<nav>

    <ul>

        <li>
            <a href="index.php">Início</a>
        </li>

        <li>
            <a href="produtos.php">Produtos</a>
        </li>

        <a href="faleConosco.php">Fale Conosco</a>

        <li>
            <a href="index.php#sobre">Sobre nós</a>
        </li>

    </ul>

    <div class="login">

        <span>Seja bem vindo(a),</span>

        <a href="login.php" id="linkUsuario">
            Entre ou Cadastre-se
        </a>

    </div>

</nav>


<!-- ================= CONTEÚDO ================= -->
<main class="container">

    <h2>Meu perfil</h2>

    <div class="breadcrumb">
        <span>Início</span>
        <i class="fa-solid fa-chevron-right"></i>
        <strong>Meu perfil</strong>
    </div>


    <div class="profile-layout">

        <!-- ================= MENU LATERAL ================= -->
        <aside class="sidebar">

            <div class="profile-user">

                <div class="profile-photo">

                    <img id="fotoPerfil"
                         src="assets/img/perfil.png"
                         alt="Foto do perfil">

                    <button class="camera" id="botaoFoto" type="button">
                        <i class="fa-solid fa-camera"></i>
                    </button>

                    <input type="file"
                           id="inputFoto"
                           accept="image/*"
                           style="display:none;">

                </div>

                <h3 id="nomePerfil"></h3>
                <p id="emailPerfil"></p>

            </div>


            <div class="sidebar-menu">

                <a href="#dados" class="selected">
                    <i class="fa-solid fa-user"></i>
                    <span>Dados pessoais</span>
                </a>

                <a href="#endereco">
                    <i class="fa-solid fa-location-dot"></i>
                    <span>Endereços</span>
                </a>

                <a href="#pedidos">
                    <i class="fa-solid fa-bag-shopping"></i>
                    <span>Histórico de compras</span>
                </a>

                <a href="#favoritos">
                    <i class="fa-solid fa-heart"></i>
                    <span>Meus favoritos</span>
                </a>

                <a href="#pagamento">
                    <i class="fa-solid fa-credit-card"></i>
                    <span>Pagamento</span>
                </a>
                <a href="#" class="logout">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                    <span>Sair da conta</span>
                </a>

            </div>
        </aside>


        <!-- ================= ÁREA PRINCIPAL ================= -->
        <section class="profile-content">


            <!-- DADOS PESSOAIS -->
            <div class="card personal-card" id="dados">

                <div class="card-header">

                    <div class="card-title">

                        <div class="card-icon">
                            <i class="fa-regular fa-user"></i>
                        </div>

                        <h3>Dados pessoais</h3>

                    </div>



                </div>


                <div class="personal-info">

                    <div class="info-column">

                        <div class="info-item">
                            <span>Nome completo</span>
                            <strong id="nomeUsuario"></strong>
                        </div>

                        <div class="info-item">
                            <span>E-mail</span>
                            <strong id="emailUsuario"></strong>
                        </div>

                    </div>


                    <div class="info-column">

                        <div class="info-item">
                            <span>Data de nascimento</span>
                            <strong id="nascimentoUsuario"></strong>
                        </div>

                        <div class="info-item">
                            <span>Telefone</span>
                            <strong id="telefoneUsuario"></strong>
                        </div>

                    </div>


                    <div class="info-column">

                        <div class="info-item">
                            <span>CPF</span>
                            <strong id="cpfUsuario"></strong>
                        </div>

                    </div>

                </div>

            </div>


            <!-- ENDEREÇO -->
            <!-- ENDEREÇO -->
            <div class="card address-card" id="endereco">

                <div class="card-header">

                    <div class="card-title">

                        <div class="card-icon">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>

                        <h3>Endereço principal</h3>

                    </div>

                    <a href="#" class="edit">
                        Editar
                        <i class="fa-solid fa-pencil"></i>
                    </a>

                </div>

                <div class="address-info" id="enderecoInfo">

                    <p>Nenhum endereço cadastrado.</p>

                </div>

            </div>

            <!-- HISTÓRICO DE COMPRAS -->
            <div class="card orders-card" id="pedidos">

                <div class="card-header">

                    <div class="card-title">

                        <div class="card-icon">
                            <i class="fa-solid fa-bag-shopping"></i>
                        </div>

                        <h3>Histórico de compras</h3>

                    </div>



                </div>


                <div class="orders-table" id="listaPedidos">

                    <p>Nenhum pedido realizado.</p>

                </div>


            </div>

            <!-- FAVORITOS -->

            <div class="card" id="favoritos">

                <div class="card-header">

                    <div class="card-title">

                        <div class="card-icon">
                            <i class="fa-solid fa-heart"></i>
                        </div>

                        <h3>Meus favoritos</h3>

                    </div>

                </div>

                <div id="listaFavoritos">

                    <p>Nenhum produto favorito.</p>

                </div>

            </div>


            <!-- PAGAMENTO -->

            <div class="card" id="pagamento">

                <div class="card-header">

                    <div class="card-title">

                        <div class="card-icon">
                            <i class="fa-solid fa-credit-card"></i>
                        </div>

                        <h3>Forma de pagamento</h3>

                    </div>

                </div>

                <p id="formaPagamento">
                    Nenhuma forma de pagamento escolhida.
                </p>

            </div>
        </section>

    </div>

</main>
<footer>

    <div class="footerContainer">

        <div>

            <h3>Remédios da Vovó</h3>

            <p>
                Qualidade, confiança e cuidado com a sua saúde.
            </p>

        </div>


        <div>

            <h3>Contato</h3>

            <p>(11) 99999-9999</p>

            <p>contato@remediosdavovo.com.br</p>

        </div>

        <div>

            <h3>Horário</h3>

            <p>Segunda a Sexta</p>

            <p>08:00 às 18:00</p>

        </div>

    </div>

    <div class="copyright">

        © 2026 Remédios da Vovó - Todos os direitos reservados.

    </div>

</footer>



<script src="assets/scripts/usuario.js"></script>
<script src="assets/scripts/nav.js"></script>


</body>
</html>
